console.log("Spotify clone loaded");

let currentSong = new Audio();
let songs = [];
let currFolder = "";
let currentIndex = 0;
let playlists = [];

function secondsToMinutesSeconds(seconds) {
  if (isNaN(seconds) || seconds < 0) return "00:00";
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${String(minutes).padStart(2, "0")}:${String(remainingSeconds).padStart(2, "0")}`;
}

function encodePathPart(value) {
  return encodeURIComponent(value).replace(/%2F/g, "/");
}

function songUrl(folder, track) {
  return `songs/${encodePathPart(folder)}/${encodePathPart(track)}`;
}

function renderSongList() {
  const songUL = document.querySelector(".songList ul");
  songUL.innerHTML = songs.map((song) => `
    <li><img class="invert" width="34" src="img/music.svg" alt="">
      <div class="info"><div>${song.replaceAll("/", "")}</div><div>Rafiq</div></div>
      <div class="playnow"><span>Play Now</span><img class="invert" src="img/play.svg" alt=""></div>
    </li>`).join("");
  Array.from(songUL.querySelectorAll("li")).forEach((item, index) => {
    item.addEventListener("click", () => playMusic(songs[index]));
  });
}

async function getSongs(folder) {
  currFolder = folder;
  const playlist = playlists.find((item) => item.folder === folder);
  songs = playlist ? playlist.songs : [];
  currentIndex = 0;
  renderSongList();
  return songs;
}

function playMusic(track, pause = false) {
  currentIndex = Math.max(0, songs.indexOf(track));
  currentSong.src = songUrl(currFolder, track);
  if (!pause) {
    currentSong.play().catch(() => {});
    document.querySelector("#play").src = "img/pause.svg";
  }
  document.querySelector(".songinfo").textContent = track.replaceAll("/", "");
  document.querySelector(".songtime").textContent = "00:00 / 00:00";
}

function displayAlbums() {
  const cardContainer = document.querySelector(".cardContainer");
  cardContainer.innerHTML = playlists.map((playlist) => `
    <div data-folder="${playlist.folder}" class="card">
      <div class="play"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5 20V4L19 12L5 20Z" stroke="#141B34" stroke-width="1.5" stroke-linejoin="round" /></svg></div>
      <img src="songs/${encodePathPart(playlist.folder)}/cover.jpg" alt="${playlist.title}">
      <h2>${playlist.title}</h2><p>${playlist.description}</p>
    </div>`).join("");
  Array.from(document.getElementsByClassName("card")).forEach((card) => {
    card.addEventListener("click", async () => {
      await getSongs(card.dataset.folder);
      if (songs.length) playMusic(songs[0]);
    });
  });
}

async function main() {
  const response = await fetch("songs.json");
  const data = await response.json();
  playlists = data.playlists || [];
  displayAlbums();
  const defaultPlaylist = playlists.find((item) => item.folder === "ncs") || playlists[0];
  if (defaultPlaylist && defaultPlaylist.songs.length) {
    await getSongs(defaultPlaylist.folder);
    playMusic(songs[0], true);
  }

  document.querySelector("#play").addEventListener("click", () => {
    if (currentSong.paused) {
      currentSong.play().catch(() => {});
      document.querySelector("#play").src = "img/pause.svg";
    } else {
      currentSong.pause();
      document.querySelector("#play").src = "img/play.svg";
    }
  });
  currentSong.addEventListener("timeupdate", () => {
    document.querySelector(".songtime").textContent = `${secondsToMinutesSeconds(currentSong.currentTime)} / ${secondsToMinutesSeconds(currentSong.duration)}`;
    const progress = currentSong.duration ? (currentSong.currentTime / currentSong.duration) * 100 : 0;
    document.querySelector(".circle").style.left = `${progress}%`;
  });
  currentSong.addEventListener("loadedmetadata", () => {
    document.querySelector(".songtime").textContent = `00:00 / ${secondsToMinutesSeconds(currentSong.duration)}`;
  });
  const seekbar = document.querySelector(".seekbar");
  const seekToPointer = (event) => {
    if (!Number.isFinite(currentSong.duration) || currentSong.duration <= 0) return;
    const bounds = seekbar.getBoundingClientRect();
    const position = Math.min(Math.max(event.clientX - bounds.left, 0), bounds.width);
    const percent = (position / bounds.width) * 100;
    currentSong.currentTime = (currentSong.duration * percent) / 100;
    document.querySelector(".circle").style.left = `${percent}%`;
  };
  seekbar.addEventListener("click", seekToPointer);
  document.querySelector(".hamburger").addEventListener("click", () => { document.querySelector(".left").style.left = "0"; });
  document.querySelector(".close").addEventListener("click", () => { document.querySelector(".left").style.left = "-120%"; });
  document.querySelector("#previous").addEventListener("click", () => { if (currentIndex > 0) playMusic(songs[currentIndex - 1]); });
  document.querySelector("#next").addEventListener("click", () => { if (currentIndex + 1 < songs.length) playMusic(songs[currentIndex + 1]); });
  const volumeInput = document.querySelector(".range input");
  volumeInput.addEventListener("change", (event) => { currentSong.volume = Number(event.target.value) / 100; });
  document.querySelector(".volume>img").addEventListener("click", (event) => {
    const muted = event.target.src.includes("volume.svg");
    event.target.src = muted ? "img/mute.svg" : "img/volume.svg";
    currentSong.volume = muted ? 0 : 0.1;
    volumeInput.value = muted ? 0 : 10;
  });
}

main().catch((error) => console.error("Unable to load Spotify clone:", error));
